const routes = [
  {
    path: ["/", "/home"],
    exact: true,
    component: "Home",
  },
  {
    path: "/tasks",       // URL path for your page
    component: "TaskPage", // the component filename without extension
    exact: true,
  },
];

export default routes;
