import React, { useEffect, useState } from "react";
import styled from "styled-components";
import HeaderTask from "../components/HeaderTask";

const PageWrapper = styled.div`
  padding: 40px 20px;
  font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
  min-height: 100vh;
  display: flex;
  flex-direction: column;
  align-items: center;
  background: #f7f9fb;
  animation: fadeIn 0.5s ease-in;

  @keyframes fadeIn {
    from { opacity: 0; transform: translateY(20px); }
    to { opacity: 1; transform: translateY(0); }
  }
`;

const Heading = styled.h1`
  color: #2c3e50;
  margin-bottom: 30px;
  font-size: 2.5rem;
  text-align: center;
`;

const TableContainer = styled.div`
  width: 100%;
  max-width: 1000px;
  margin: 0 auto;
`;

const StyledTable = styled.table`
  width: 100%;
  border-collapse: collapse;
  background: white;
  border-radius: 10px;
  overflow: hidden;
  box-shadow: 0 8px 18px rgba(0, 0, 0, 0.08);
  transition: all 0.3s ease;

  thead {
    background-color: #34495e;
  }

  tbody tr {
    transition: background-color 0.3s ease;

    &:nth-child(even) {
      background-color: #f9f9f9;
    }

    &:hover {
      background-color: #f0f8ff;
    }
  }
`;

const TableHeader = styled.th<{ width?: string }>`
  color: #ffffff;
  padding: 16px 12px;
  text-align: center;
  font-size: 1.1rem;
  font-weight: 600;
  width: ${({ width }) => width || 'auto'};
  cursor: pointer;
  user-select: none;
`;

const TableCell = styled.td<{ width?: string }>`
  padding: 16px 12px;
  border-bottom: 1px solid #e0e0e0;
  font-size: 0.95rem;
  text-align: center;
  color: #333;
  width: ${({ width }) => width || 'auto'};
`;

const StatusBadge = styled.span<{ status: string }>`
  padding: 6px 14px;
  border-radius: 50px;
  font-weight: 600;
  font-size: 0.85rem;
  color: white;
  display: inline-block;
  box-shadow: 0 2px 6px rgba(0, 0, 0, 0.1);

  background-color: ${({ status }) =>
    status === "Completed" ? "#2ecc71" :
      status === "In Progress" ? "#f39c12" :
        "#e74c3c"};
`;

const CreatedAt = styled.span`
  font-size: 0.85rem;
  color: #7f8c8d;
  font-style: italic;
  white-space: nowrap;
`;

const DownloadButton = styled.a`
  text-decoration: none;
  background-color: #3498db;
  color: white;
  padding: 8px 16px;
  border-radius: 6px;
  font-weight: 500;
  font-size: 0.9rem;
  transition: background 0.3s ease, transform 0.2s ease;
  display: inline-block;

  &:hover {
    background-color: #2980b9;
    transform: translateY(-1px);
  }
`;

const Pagination = styled.div`
  display: flex;
  justify-content: center;
  margin-top: 20px;
  gap: 10px;
`;

const PageButton = styled.button<{ active?: boolean }>`
  padding: 8px 14px;
  background-color: ${({ active }) => (active ? '#3498db' : '#ecf0f1')};
  color: ${({ active }) => (active ? 'white' : '#2c3e50')};
  border: none;
  border-radius: 5px;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.3s ease;

  &:hover {
    background-color: ${({ active }) => (active ? '#2980b9' : '#d0d7de')};
  }

  &:disabled {
    background-color: #bdc3c7;
    cursor: not-allowed;
  }
`;

const FilterContainer = styled.div`
  display: flex;
  flex-wrap: wrap;
  justify-content: center;
  gap: 20px;
  padding: 20px 24px;
  background-color: #ffffff;
  border: 1px solid #e3e6ea;
  border-radius: 12px;
  box-shadow: 0 6px 15px rgb(0 0 0 / 0.07);
  font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
  margin-bottom : 20px;
`;

const FilterGroup = styled.div`
  display: flex;
  flex-direction: column;
  min-width: 180px;
  flex: 1 1 160px;
  max-width: 220px;
`;

const Label = styled.label`
  font-weight: 700;
  font-size: 0.85rem;
  color: #343a40;
  margin-bottom: 8px;
  cursor: pointer;
  user-select: none;
  transition: color 0.3s ease;
  text-align: center;

  &:hover {
    color: #4c8bf5;
  }
`;

const DateInputWrapper = styled.div`
  position: relative;
`;

const DateInput = styled.input`
  width: 100%;
  padding: 10px 38px 10px 14px;
  border: 1.5px solid #ced4da;
  border-radius: 8px;
  font-size: 1rem;
  color: #495057;
  background-color: #fff;
  transition: border-color 0.3s ease, box-shadow 0.3s ease;
  
  &:hover {
    border-color: #a6b1e1;
  }

  &:focus {
    outline: none;
    border-color: #4c8bf5;
    box-shadow: 0 0 8px #4c8bf5aa;
  }

  cursor: pointer;
  -webkit-appearance: none;
  -moz-appearance: none;
  appearance: none;
`;

// Date icon on the right side inside the input
const DateIcon = styled.div`
  position: absolute;
  right: 12px;
  top: 50%;
  transform: translateY(-50%);
  pointer-events: none;
  color: #4c8bf5;
  font-size: 18px;
  user-select: none;
`;

function DateFilters({
  createdFrom,
  createdTo,
  // completedFrom,
  // completedTo,
  setCreatedFrom,
  setCreatedTo,
  // setCompletedFrom,
  // setCompletedTo,
}: {
  createdFrom: string;
  createdTo: string;
  // completedFrom: string;
  // completedTo: string;
  setCreatedFrom: React.Dispatch<React.SetStateAction<string>>;
  setCreatedTo: React.Dispatch<React.SetStateAction<string>>;
  // setCompletedFrom: React.Dispatch<React.SetStateAction<string>>;
  // setCompletedTo: React.Dispatch<React.SetStateAction<string>>;
}) {
  return (
    <FilterContainer>
      <FilterGroup>
        <Label htmlFor="createdFrom">Start Date</Label>
        <DateInputWrapper>
          <DateInput
            id="createdFrom"
            type="date"
            value={createdFrom}
            onChange={(e) => setCreatedFrom(e.target.value)}
          />
          <DateIcon>📅</DateIcon>
        </DateInputWrapper>
      </FilterGroup>
      <FilterGroup>
        <Label htmlFor="createdTo">End Date</Label>
        <DateInputWrapper>
          <DateInput
            id="createdTo"
            type="date"
            value={createdTo}
            onChange={(e) => setCreatedTo(e.target.value)}
          />
          <DateIcon>📅</DateIcon>
        </DateInputWrapper>
      </FilterGroup>
      {/* <FilterGroup>
        <Label htmlFor="completedFrom">Completed From</Label>
        <DateInputWrapper>
          <DateInput
            id="completedFrom"
            type="date"
            value={completedFrom}
            onChange={(e) => setCompletedFrom(e.target.value)}
          />
          <DateIcon>📅</DateIcon>
        </DateInputWrapper>
      </FilterGroup>
      <FilterGroup>
        <Label htmlFor="completedTo">Completed To</Label>
        <DateInputWrapper>
          <DateInput
            id="completedTo"
            type="date"
            value={completedTo}
            onChange={(e) => setCompletedTo(e.target.value)}
          />
          <DateIcon>📅</DateIcon>
        </DateInputWrapper>
      </FilterGroup> */}
    </FilterContainer>
  );
}

type Task = {
  title: string;
  audio_duration : string;
  status: string;
  transcript_file: string;
  created_at: string;
};

const TaskPage: React.FC = () => {
  const [tasks, setTasks] = useState<Task[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [sortConfig, setSortConfig] = useState<{ key: keyof Task, direction: 'asc' | 'desc' } | null>(null);
  const [createdFrom, setCreatedFrom] = useState("");
  const [createdTo, setCreatedTo] = useState("");
  // const [completedFrom, setCompletedFrom] = useState("");
  // const [completedTo, setCompletedTo] = useState("");



  const [currentPage, setCurrentPage] = useState(1);
  const tasksPerPage = 5;

  useEffect(() => {
    const userId = 1;

    const fetchTasks = () => {
      fetch(`http://127.0.0.1:5000/api/track/user/${userId}`)
        .then((res) => {
          if (!res.ok) {
            throw new Error("Failed to fetch tasks");
          }
          return res.json();
        })
        .then((data) => {
          setTasks(data.tasks);
          setLoading(false);
        })
        .catch((err) => {
          setError(err.message);
          setLoading(false);
        });
    };

    fetchTasks();
    const interval = setInterval(fetchTasks, 5000);
    return () => clearInterval(interval);
  }, []);

  const requestSort = (key: keyof Task) => {
    let direction: 'asc' | 'desc' = 'asc';
    if (sortConfig && sortConfig.key === key && sortConfig.direction === 'asc') {
      direction = 'desc';
    }
    setSortConfig({ key, direction });
    setCurrentPage(1);
  };

  // const sortedTasks = React.useMemo(() => {
  //   let filteredTasks = [...tasks];

  //   if (createdFrom) {
  //     filteredTasks = filteredTasks.filter(t => new Date(t.created_at) >= new Date(createdFrom));
  //   }
  //   if (createdTo) {
  //     filteredTasks = filteredTasks.filter(t => new Date(t.created_at) <= new Date(createdTo));
  //   }
  //   // if (completedFrom) {
  //   //   filteredTasks = filteredTasks.filter(t => new Date(t.completed_at) >= new Date(completedFrom));
  //   // }
  //   // if (completedTo) {
  //   //   filteredTasks = filteredTasks.filter(t => new Date(t.completed_at) <= new Date(completedTo));
  //   // }

  //   if (sortConfig !== null) {
  //     filteredTasks.sort((a, b) => {
  //       const aValue = a[sortConfig.key];
  //       const bValue = b[sortConfig.key];

  //       // if (sortConfig.key === "created_at" || sortConfig.key === "completed_at") {
  //       //   return sortConfig.direction === 'asc'
  //       //     ? new Date(aValue).getTime() - new Date(bValue).getTime()
  //       //     : new Date(bValue).getTime() - new Date(aValue).getTime();
  //       // }

  //       // if (aValue < bValue) return sortConfig.direction === 'asc' ? -1 : 1;
  //       // if (aValue > bValue) return sortConfig.direction === 'asc' ? 1 : -1;
  //       // return 0;
  //        if (sortConfig.key === "created_at") {
  //         return sortConfig.direction === 'asc'
  //           ? new Date(aValue).getTime() - new Date(bValue).getTime()
  //           : new Date(bValue).getTime() - new Date(aValue).getTime();
  //       }

  //       if (aValue < bValue) return sortConfig.direction === 'asc' ? -1 : 1;
  //       if (aValue > bValue) return sortConfig.direction === 'asc' ? 1 : -1;
  //       return 0;
  //     });
  //   }

  //   return filteredTasks;
  // }, [tasks, sortConfig, createdFrom, createdTo]);

  // }, [tasks, sortConfig, createdFrom, createdTo, completedFrom, completedTo]);

  const sortedTasks = React.useMemo(() => {
  let filteredTasks = [...tasks];

  if (createdFrom) {
    filteredTasks = filteredTasks.filter(t => new Date(t.created_at) >= new Date(createdFrom));
  }
  if (createdTo) {
    filteredTasks = filteredTasks.filter(t => new Date(t.created_at) <= new Date(createdTo));
  }

  if (sortConfig !== null) {
    filteredTasks.sort((a, b) => {
      const aValue = a[sortConfig.key];
      const bValue = b[sortConfig.key];

      // Convert audio_duration string like "1:11" to seconds
      if (sortConfig.key === "audio_duration") {
        const toSeconds = (duration: string) => {
          const parts = duration.split(":").map(Number);
          if (parts.length === 2) {
            return parts[0] * 60 + parts[1]; // mm:ss
          } else if (parts.length === 3) {
            return parts[0] * 3600 + parts[1] * 60 + parts[2]; // hh:mm:ss (in case you extend format)
          }
          return 0;
        };

        return sortConfig.direction === 'asc'
          ? toSeconds(aValue as string) - toSeconds(bValue as string)
          : toSeconds(bValue as string) - toSeconds(aValue as string);
      }

      // Handle date sorting
      if (sortConfig.key === "created_at") {
        return sortConfig.direction === 'asc'
          ? new Date(aValue).getTime() - new Date(bValue).getTime()
          : new Date(bValue).getTime() - new Date(aValue).getTime();
      }

      // Default comparison for strings or other fields
      if (aValue < bValue) return sortConfig.direction === 'asc' ? -1 : 1;
      if (aValue > bValue) return sortConfig.direction === 'asc' ? 1 : -1;
      return 0;
    });
  }

  return filteredTasks;
}, [tasks, sortConfig, createdFrom, createdTo]);



  const totalPages = Math.ceil(sortedTasks.length / tasksPerPage);
  const paginatedTasks = React.useMemo(() => {
    const start = (currentPage - 1) * tasksPerPage;
    return sortedTasks.slice(start, start + tasksPerPage);
  }, [sortedTasks, currentPage]);

  if (loading && tasks.length === 0) return <PageWrapper>Loading tasks...</PageWrapper>;
  if (error) return <PageWrapper>Error: {error}</PageWrapper>;

  const getArrow = (key: keyof Task) => {
    if (sortConfig?.key !== key) return '';
    return sortConfig.direction === 'asc' ? ' ↑' : ' ↓';
  };

  return (
    <>
      <HeaderTask />
      <PageWrapper>
        <Heading>Task Tracking Dashboard</Heading>
        <DateFilters
          createdFrom={createdFrom}
          createdTo={createdTo}
          // completedFrom={completedFrom}
          // completedTo={completedTo}
          setCreatedFrom={setCreatedFrom}
          setCreatedTo={setCreatedTo}
          // setCompletedFrom={setCompletedFrom}
          // setCompletedTo={setCompletedTo}
        />
        <TableContainer>
          <StyledTable>
            <thead>
              <tr>
                <TableHeader width="25%" onClick={() => requestSort('title')}>
                  Task{getArrow('title')}
                </TableHeader>
                <TableHeader width="25%" onClick={() => requestSort('audio_duration')}>
                  Duration{getArrow('audio_duration')}
                </TableHeader>
                <TableHeader width="15%" onClick={() => requestSort('status')}>
                  Status{getArrow('status')}
                </TableHeader>
                <TableHeader width="15%">
                  Download
                </TableHeader>
                <TableHeader width="15%" onClick={() => requestSort('created_at')}>
                  Created At{getArrow('created_at')}
                </TableHeader>
               
              </tr>
            </thead>
            <tbody>
              {paginatedTasks.map((task, i) => (
                <tr key={i}>
                  <TableCell width="25%">{task.title}</TableCell>
                  <TableCell width="25%">{task.audio_duration}</TableCell>

                  <TableCell width="15%">
                    <StatusBadge status={task.status}>{task.status}</StatusBadge>
                  </TableCell>
                  <TableCell width="15%">
                    {task.status === "Completed" ? (
                      <DownloadButton
                        href={`http://127.0.0.1:5000/${task.transcript_file}`}
                        target="_blank"
                        rel="noopener noreferrer"
                        download
                      >
                        Download
                      </DownloadButton>
                    ) : (
                      <span style={{ color: "#aaa" }}>Not Available</span>
                    )}
                  </TableCell>
                  <TableCell width="15%">
                    <CreatedAt>{task.created_at}</CreatedAt>
                  </TableCell>
                 
                </tr>
              ))}
            </tbody>
          </StyledTable>
          {totalPages > 1 && (
            <Pagination>
              <PageButton
                onClick={() => setCurrentPage((prev) => Math.max(prev - 1, 1))}
                disabled={currentPage === 1}
              >
                Prev
              </PageButton>
              {Array.from({ length: totalPages }, (_, i) => (
                <PageButton
                  key={i}
                  active={currentPage === i + 1}
                  onClick={() => setCurrentPage(i + 1)}
                >
                  {i + 1}
                </PageButton>
              ))}
              <PageButton
                onClick={() => setCurrentPage((prev) => Math.min(prev + 1, totalPages))}
                disabled={currentPage === totalPages}
              >
                Next
              </PageButton>
            </Pagination>
          )}
        </TableContainer>
      </PageWrapper>
    </>
  );
};

export default TaskPage;
