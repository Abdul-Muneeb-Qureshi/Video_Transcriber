import React, { useState, ChangeEvent, FormEvent } from 'react';

import './LinkUploadForm.css';
import { useHistory } from "react-router-dom";

const LinkUploadForm: React.FC = () => {
  const [youtubeLink, setYoutubeLink] = useState<string>('');
  const [isProcessing, setIsProcessing] = useState<boolean>(false);
  const [message, setMessage] = useState<string | null>(null);
  const [messageType, setMessageType] = useState<'success' | 'error' | null>(null);
  // const [tasks, setTasks] = useState<any[]>([]);

  const history = useHistory();



 const handleSend = async () => {
  setIsProcessing(true);

  try {
    // Step 1: Check for incomplete tasks
    const userId = 1;
    const response = await fetch(`http://127.0.0.1:5000/api/track/user/${userId}`);

    if (!response.ok) throw new Error("Failed to fetch tasks");

    const data = await response.json();
    const hasIncomplete = data.tasks.some((task: any) => task.status !== 'Completed');

    if (hasIncomplete) {
      setMessage("You have an ongoing task. Please wait for it to finish.");
      setMessageType('error');
      return;
    }

    // Step 2: No incomplete tasks, send request
    const uploadResponse = await fetch('http://127.0.0.1:5000/api/download', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ url: youtubeLink }),
    });

    if (!uploadResponse.ok) throw new Error('Failed to fetch text file');

    setMessage('Process Successfully Start');
    setMessageType('success');

  } catch (error) {
    setMessage('Failed to send the link.');
    setMessageType('error');
  } finally {
    setIsProcessing(false);
  }
};


  const handleTasks = () => {
    history.push("/tasks")
    
  };

  const handleChange = (e: ChangeEvent<HTMLInputElement>) => {
    setYoutubeLink(e.target.value);
  };

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
  };

  return (
    <div className="form-container" id="upload">

      {isProcessing && (
        <div className="loader-overlay">
          <div className="spinner"></div>
        </div>)}


      {message && (
        <div
          className={`message-popup ${messageType}`}
          onClick={() => {
            if (messageType === 'success') {
              handleTasks(); // Trigger tasks page
            }
            setMessage(null); // Close popup
          }}
        >
          {message}
          <button className="close-button" onClick={(e) => {
            e.stopPropagation(); // Prevent download when only closing
            setMessage(null);
          }}>×</button>
        </div>
      )}
      <div className="form-box" >
        <div className="form-image">
          <img src="/img/svg/Picture6.png" alt="Illustration" />

        </div>

        <div className="form-content">
          {/* {isProcessing && <div className="spinner"></div>} */}

          <form onSubmit={handleSubmit}>
            <h2 className="form-title">Upload Youtube Link</h2>

            <label htmlFor="youtubeLink">Enter Your Link</label>
            <input
              type="url"
              id="youtubeLink"
              value={youtubeLink}
              onChange={handleChange}
              placeholder="https://www.youtube.com/watch?v=..."
              className="form-input"
              required
              disabled={isProcessing}
            />

            <div className="button-group">
              <button
                type="button"
                className="form-button send-button"
                onClick={handleSend}
                disabled={isProcessing}
              >
                <img src="/img/svg/start_icon.png" alt="Process" className="button-icon" />

                {isProcessing ? 'Processing...' : 'Start Process'}
              </button>
            
            </div>
          </form>
        </div>

      </div>
    </div>
  );
};

export default LinkUploadForm;
