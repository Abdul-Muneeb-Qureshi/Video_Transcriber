import { Row, Col } from "antd";
import { withTranslation, TFunction } from "react-i18next";
import { SvgIcon } from "../../common/SvgIcon";
import Container from "../../common/Container";

import i18n from "i18next";
import {
  FooterSection,
  Title,
  NavLink,
  Extra,
  LogoContainer,
  Para,
  Large,
  Chat,
  Empty,
  FooterContainer,
  Language,
  Label,
  LanguageSwitch,
  LanguageSwitchContainer,
  LargeExternal,
} from "./styles";

interface SocialLinkProps {
  href: string;
  src: string;
}

const Footer = ({ t }: { t: TFunction }) => {
  const handleChange = (language: string) => {
    i18n.changeLanguage(language);
  };

  const SocialLink = ({ href, src }: SocialLinkProps) => {
    return (
      <a
        href={href}
        target="_blank"
        rel="noopener noreferrer"
        key={src}
        aria-label={src}
      >
        <SvgIcon src={src} width="25px" height="25px" />
      </a>
    );
  };

  return (
    <>
      <FooterSection>
        <Container>
          <Row justify="space-between">
            <Col lg={10} md={10} sm={12} xs={12}>
              <Language>{t("Contact")}</Language>
              <Large to="/">{t("Tell us everything")}</Large>
              <Para>
                {t(`Do you have any question? Feel free to reach out.`)}
              </Para>
              <a href="mailto:info@kics.edu.pk">
                <Chat>{t(`Let's Chat`)}</Chat>
              </a>
            </Col>
            <Col lg={8} md={8} sm={12} xs={12}>
              <Title>{t("Policy")}</Title>
              <LargeExternal href="https://kics.edu.pk/web/plagiarism-policy/" target="_blank" rel="noopener noreferrer">
                {t("Plagiarism ")}
              </LargeExternal>
              <LargeExternal href="https://kics.edu.pk/web/services/application-software-and-erp-development-services/" target="_blank" rel="noopener noreferrer">
                {t("Software Principles")}
              </LargeExternal>
            </Col>

            <Col lg={6} md={6} sm={12} xs={12}>
              <Empty />
              <LargeExternal
                href="https://kics.edu.pk/web/downloads/"
                target="_blank"
                rel="noopener noreferrer"
              >
                {t("Downloads")}
              </LargeExternal>
              <LargeExternal
                href="https://kics.edu.pk/web/icosst-2021/"
                target="_blank"
                rel="noopener noreferrer"
              >
                {t("Conferences")}
              </LargeExternal>
            </Col>

          </Row>
          <Row justify="space-between">
            <Col lg={10} md={10} sm={12} xs={12}>
              <Empty />
              <Language>{t("Address")}</Language>
              <Para>Center for Language Engineering (CLE)</Para>
              <Para>University of Engineering and Technology (UET)</Para>
              <Para>G.T. Road, Lahore 54890, Pakistan</Para>
            </Col>
            <Col lg={8} md={8} sm={12} xs={12}>
              <Title>{t("Company")}</Title>
              <LargeExternal href="https://kics.edu.pk/web/what-we-are/about-us/" target="_blank" rel="noopener noreferrer">{t("About")}</LargeExternal>
              <LargeExternal href="https://kics.edu.pk/web/whats-new/latest-news/" target="_blank" rel="noopener noreferrer">{t("Latest News")}</LargeExternal>
              <LargeExternal href="https://kics.edu.pk/web/services/clients/" target="_blank" rel="noopener noreferrer">{t("Clients")}</LargeExternal>
              <LargeExternal href="https://kics.edu.pk/web/jobs/" target="_blank" rel="noopener noreferrer">{t("Careers & Culture")}</LargeExternal>
            </Col>

            <Col lg={6} md={6} sm={12} xs={12}>
              <Label htmlFor="select-lang">{t("Language")}</Label>
              <LanguageSwitchContainer>
                <LanguageSwitch onClick={() => handleChange("en")}>
                  <SvgIcon
                    src="united-states.svg"
                    aria-label="homepage"
                    width="30px"
                    height="30px"
                  />
                </LanguageSwitch>
                {/* <LanguageSwitch onClick={() => handleChange("es")}>
                  <SvgIcon
                    src="pakistan.png"
                    aria-label="homepage"
                    width="35px"
                    height="35px"
                  />
                </LanguageSwitch> */}
              </LanguageSwitchContainer>
            </Col>
          </Row>
        </Container>
      </FooterSection>
      <Extra>
        <Container border={true}>
          <Row
            justify="space-between"
            align="middle"
            style={{ paddingTop: "3rem" }}
          >
            <NavLink to="/">
              <LogoContainer>
                <SvgIcon
                  src="cle-logo-footer.png"
                  aria-label="homepage"
                 width="156.4px" height="68.1px"
                />
              </LogoContainer>
            </NavLink>
            <FooterContainer>
              <SocialLink
                href="https://www.facebook.com/CenterForLanguageEngineering"
                src="facebook.svg"
              />
              <SocialLink
                href="https://x.com/KICSUETLAHORE"
                src="twitter.svg"
              />
              <SocialLink
                href="https://www.linkedin.com/company/center-for-language-engineering/"
                src="linkedin.svg"
              />
              <SocialLink
                href="https://www.instagram.com/centerforlanguageengineering/"
                src="instagram.svg"
              />
              <a
                href="https://ko-fi.com/Y8Y7H8BNJ"
                target="_blank"
                rel="noopener noreferrer"
              >

              </a>
            </FooterContainer>
          </Row>
        </Container>
      </Extra>
    </>
  );
};

export default withTranslation()(Footer);
