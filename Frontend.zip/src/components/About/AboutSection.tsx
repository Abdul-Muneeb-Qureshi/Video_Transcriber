import React from 'react';
import './AboutSection.css';

const AboutSection: React.FC = () => {
  return (
    <section className="about-container" id="about">
      <div className="about-box">
        <div className="about-content">
          <div className="about-text-section">
            <h2 className="about-title">Simplify Your Video Research</h2>
            <p className="about-subtitle">
              Turn YouTube content into actionable insights.
            </p>
            <p className="about-text">
              Our platform lets you extract, convert, and analyze YouTube video content in one seamless experience. Just paste a link, and get clean, structured text—ready to save, search, or share.
            </p>
            <p className="about-text">
              Whether you're a student, researcher, or content creator, we prioritize your privacy, speed, and simplicity to enhance your workflow.
            </p>
          </div>
          <div className="about-image-section">
            <img src="/img/svg/About us page-amico.png" alt="About our platform" className="about-image" />
          </div>
        </div>
      </div>
    </section>
  );
};

export default AboutSection;
