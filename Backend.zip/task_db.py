import pymysql
from pymysql.err import MySQLError

def get_connection():
    try:
        conn = pymysql.connect(
            host="localhost",
            user="root",
            password="pakistan@123",
            database="youtube_tasks_db",
            connect_timeout=5
        )
        print("MySQL connection established")
        return conn
    except MySQLError as e:
        print(f"Error connecting to MySQL: {e}")
        return None

# -------------------- USER TABLE CRUD --------------------

def create_user(name):
    conn = get_connection()
    if conn is None:
        return
    cursor = conn.cursor()
    cursor.execute("INSERT INTO users (name) VALUES (%s)", (name,))
    conn.commit()
    cursor.close()
    conn.close()

def get_all_users():
    conn = get_connection()
    if conn is None:
        return []
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM users")
    users = cursor.fetchall()
    cursor.close()
    conn.close()
    return users

def get_user_by_id(user_id):
    conn = get_connection()
    if conn is None:
        return None
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM users WHERE id = %s", (user_id,))
    user = cursor.fetchone()
    cursor.close()
    conn.close()
    return user

def update_user(user_id, new_name):
    conn = get_connection()
    if conn is None:
        return
    cursor = conn.cursor()
    cursor.execute("UPDATE users SET name = %s WHERE id = %s", (new_name, user_id))
    conn.commit()
    cursor.close()
    conn.close()

def delete_user(user_id):
    conn = get_connection()
    if conn is None:
        return
    cursor = conn.cursor()
    cursor.execute("DELETE FROM users WHERE id = %s", (user_id,))
    conn.commit()
    cursor.close()
    conn.close()

# -------------------- TASK STATUS TABLE CRUD --------------------

def create_task(task_id, user_id, title):
    conn = None
    cursor = None
    try:
        conn = get_connection()
        if conn is None:
            return
        cursor = conn.cursor()
        cursor.execute(
            "INSERT INTO task_status (id, user_id, video_title, status , audio_duration) VALUES (%s, %s, %s, %s, %s)",
            (task_id, user_id, title, "Started" ,  "_")
        )
        conn.commit()
        print("Task created successfully.")
    except MySQLError as e:
        print(f"Error creating task: {e}")
        if conn:
            conn.rollback()
    finally:
        if cursor:
            cursor.close()
        if conn:
            conn.close()

def get_task_by_id(task_id):
    conn = get_connection()
    if conn is None:
        return None
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM task_status WHERE id = %s", (task_id,))
    task = cursor.fetchone()
    cursor.close()
    conn.close()
    return task

def get_tasks_by_user(user_id):
    conn = get_connection()
    if conn is None:
        return []
    cursor = conn.cursor()
    cursor.execute(
        "SELECT video_title, status, audio_duration , transcript_link , created_at  FROM task_status WHERE user_id = %s order by created_at desc",
        (user_id,)
    )
    tasks = cursor.fetchall()
    cursor.close()
    conn.close()
    return tasks

def update_task_status(task_id, new_status):
    conn = get_connection()
    if conn is None:
        return
    cursor = conn.cursor()

    if new_status.lower() == 'completed':
        cursor.execute("""
            UPDATE task_status 
            SET status = %s, completed_at = NOW() 
            WHERE id = %s
        """, (new_status, task_id))
    else:
        cursor.execute("""
            UPDATE task_status 
            SET status = %s 
            WHERE id = %s
        """, (new_status, task_id))

    conn.commit()
    cursor.close()
    conn.close()


def update_download_link(task_id, download_link):
    conn = get_connection()
    if conn is None:
        return
    cursor = conn.cursor()
    cursor.execute("UPDATE task_status SET audio_download_link = %s WHERE id = %s", (download_link, task_id))
    conn.commit()
    cursor.close()
    conn.close()

def delete_task(task_id):
    conn = get_connection()
    if conn is None:
        return
    cursor = conn.cursor()
    cursor.execute("DELETE FROM task_status WHERE id = %s", (task_id,))
    conn.commit()
    cursor.close()
    conn.close()

def update_task_title(task_id, title):
    conn = get_connection()
    if conn is None:
        return
    cursor = conn.cursor()
    cursor.execute("UPDATE task_status SET video_title = %s WHERE id = %s", (title, task_id))
    conn.commit()
    cursor.close()
    conn.close()

def update_task_audio_info(task_id, audio_path, audio_duration):
    # Example: Update audio_download_link and audio_duration in your DB
    conn = get_connection()
    if conn is None:
        return
    cursor = conn.cursor()
    cursor.execute(
        "UPDATE task_status SET audio_download_link = %s, audio_duration = %s WHERE id = %s",
        (audio_path, audio_duration, task_id)
    )
    conn.commit()
    conn.close()


def update_task_transcript_path(task_id, transcript_path):
    # Example: Update audio_path column in your DB
    conn = get_connection()
    if conn is None:
        return
    cursor = conn.cursor()
    cursor.execute("UPDATE task_status SET transcript_link=%s WHERE id=%s", (transcript_path, task_id))
    conn.commit()
    conn.close()

