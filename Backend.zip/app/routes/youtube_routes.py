from flask import Blueprint, request, jsonify
from ..services.youtube_service import download_audio_from_youtube
from task_db import create_task, get_tasks_by_user
import uuid
import threading
from flask import send_file
import os

youtube_bp = Blueprint('youtube', __name__)

@youtube_bp.route('/download', methods=['POST'])
def download_audio():
    data = request.get_json()
    url = data.get('url')
    if not url:
        return jsonify({"error": "No URL provided"}), 400

    task_id = str(uuid.uuid4())
    user_id = 1  # Predefined user ID
    create_task(task_id, user_id, "Starting...")

    # Background task
    def background_task():
        download_audio_from_youtube(url, task_id)

    thread = threading.Thread(target=background_task)
    thread.start()

    return jsonify({
        "message": "Download started. You can track using /track/<task_id> or /track/user/<user_id>",
        "task_id": task_id
    })


@youtube_bp.route('/track/user/<int:user_id>', methods=['GET'])
def track_progress_by_user(user_id):
    tasks = get_tasks_by_user(user_id)
    print(tasks)

    # if not tasks:
    #     return jsonify({"error": "No tasks found for this user"}), 404
    
    task_list = []

    for title, status, audio_duration, transcript_link , created_at  in tasks:
        if transcript_link:
            filename = os.path.basename(transcript_link)  # safe now
            transcript_download_url = f"/api/download/transcript/{filename}"
        else:
            filename = None
            transcript_download_url = None  # or set to a default message or URL

        task_list.append({
            "title": title,
            "audio_duration": audio_duration,
            "status": status,
            "transcript_file": transcript_download_url,
            "created_at" : created_at,
        })
    
    return jsonify({"tasks": task_list})


@youtube_bp.route('/download/transcript/<path:transcript_link>', methods=['GET'])
def download_transcript(transcript_link):
    filename = os.path.basename(transcript_link)

    transcript_folder = r'D:\Internship\Task2\backend\downloaded_audio'  # update to your actual folder path
    file_path = os.path.join(transcript_folder, filename)

    if not os.path.exists(file_path):
        return jsonify({"error": "Transcript file not found"}), 404

    return send_file(file_path, as_attachment=True)



@youtube_bp.route('/test', methods=['GET'])
def test_server():
    return jsonify({'message': 'Server is running!'}), 200
