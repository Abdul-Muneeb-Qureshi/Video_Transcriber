import os
import time
import subprocess
import re
import string
from task_db import update_task_status, update_task_title, update_task_audio_info , update_task_transcript_path
import json

def convert_to_short_youtube_url(url):
    match = re.search(r"v=([a-zA-Z0-9_-]+)", url)
    if match:
        return f"https://youtu.be/{match.group(1)}"
    return url

def sanitize_filename(title):
    valid_chars = f"-_.() {string.ascii_letters}{string.digits}"
    return ''.join(c if c in valid_chars else '_' for c in title)

def transcriptGenerator(audio_bytes , task_id , user_id):
    output_folder = "downloaded_audio"

    print("Simulating processing...")
    time.sleep(1)
    txt_file_path = os.path.join(output_folder, f"{task_id}_result.txt")
    transcript_result = "Transcript Generate Successfully"
    with open(txt_file_path, "w", encoding="utf-8") as f:
            f.write(transcript_result)

    return txt_file_path

def download_audio_from_youtube(url, task_id):
    try:
        url = convert_to_short_youtube_url(url)
        update_task_status(task_id, "Fetching Title")

        cmd_title = f'yt-dlp --get-title {url}'
        title_result = subprocess.check_output(cmd_title, shell=True, text=True).strip()
        sanitized_title = sanitize_filename(title_result)
        update_task_title(task_id, sanitized_title)

        update_task_status(task_id, "Downloading Audio")

        output_folder = "downloaded_audio"
        os.makedirs(output_folder, exist_ok=True)

        ffmpeg_path = r"D:\Application\ffmpeg\ffmpeg-master-latest-win64-gpl\bin"
        output_file = os.path.join(output_folder, f"{sanitized_title}.mp3")
        command = f'yt-dlp -x --audio-format mp3 --ffmpeg-location "{ffmpeg_path}" -o "{output_file}" {url}'
        subprocess.run(command, shell=True, check=True)

        if not os.path.isfile(output_file):
            raise FileNotFoundError("MP3 file not found.")
        
        ffprobe_path = os.path.join(ffmpeg_path, "ffprobe.exe")
        audio_duration = get_audio_duration(output_file, ffprobe_path)
        update_task_audio_info(task_id, output_file , audio_duration)

        with open(output_file, "rb") as audio_file:
            audio_data = audio_file.read()
        
        user_id = 1
        update_task_status(task_id, "Transcribing")
        transcript_file_path = transcriptGenerator(audio_data , task_id , user_id)

        update_task_status(task_id, "Completed")

        update_task_transcript_path(task_id , transcript_file_path)
      

        return {
            "message": "Download and transcription completed.",
            "txt_file": transcript_file_path
        }

    except Exception as e:
        update_task_status(task_id, f"Error: {str(e)}")
        return {"error": str(e)}




def get_audio_duration(file_path, ffprobe_path="ffprobe"):
    try:
        result = subprocess.run(
            [ffprobe_path, "-v", "error", "-show_entries", "format=duration", "-of", "json", file_path],
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True
        )
        info = json.loads(result.stdout)
        duration_seconds = float(info["format"]["duration"])
        # Format duration as minutes:seconds
        minutes = int(duration_seconds // 60)
        seconds = int(duration_seconds % 60)
        return f"{minutes}:{seconds:02d}"
    except Exception as e:
        print(f"Error extracting duration: {e}")
        return None
